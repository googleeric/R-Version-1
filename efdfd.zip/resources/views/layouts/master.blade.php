<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from demo.designing-world.com/suha-v1.3.0/home.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Apr 2020 08:02:56 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags-->
    <!-- Title-->
    <title>Suha - Multipurpose Ecommerce Mobile Template</title>
    <!-- Favicon-->
    <link rel="icon" href="../assets/img/core-img/favicon.ico">
    <!-- Stylesheet-->
    <link rel="stylesheet" href="../assets/css/style.css">
    {{-- <link rel="stylesheet" href="../assets/bootstrap.min.css"> --}}
  </head>
  <body>
    <!-- Preloader-->
    <div class="preloader" id="preloader">
      <div class="spinner-grow text-secondary" role="status">
        <div class="sr-only">Loading...</div>
      </div>
    </div>
    @include('partials.navbar')
    @include('partials.sidebar')
    @yield('content')
    @include('partials.footer')
    <!-- All JavaScript Files-->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/jquery.easing.min.js"></script>
    <script src="../assets/js/owl.carousel.min.js"></script>
    <script src="../assets/js/jquery.animatedheadline.min.js"></script>
    <script src="../assets/js/jquery.counterup.min.js"></script>
    <script src="../assets/js/wow.min.js"></script>
    <script src="../assets/js/jarallax.min.js"></script>
    <script src="../assets/js/jarallax-video.min.js"></script>
    <script src="../assets/js/default/jquery.passwordstrength.js"></script>
    <script src="../assets/js/default/dark-mode-switch.js"></script>
    <script src="../assets/js/default/active.js"></script>
  </body>

<!-- Mirrored from demo.designing-world.com/suha-v1.3.0/home.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 24 Apr 2020 08:04:19 GMT -->
</html>