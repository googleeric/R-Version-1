<!-- Footer Nav-->
<div class="footer-nav-area" id="footerNav">
  <div class="suha-footer-nav h-100">
    <ul class="h-100 d-flex align-items-center justify-content-between">
      <li class="active"><a href="home.html"><i class="lni-home"></i>Home</a></li>
      <li><a href="https://wa.me/8898946317?text=I'm%20interested%20in%20your%20car%20for%20sale"><i class="lni-whatsapp"></i>Support</a></li>
      <li><a href="tel:8898946317"><i class="lni-mobile"></i>Call</a></li>
      <li><a href="pages.html"><i class="lni-search"></i>Search</a></li>
      <li><a href="settings.html"><i class="lni-list"></i>Products</a></li>
    </ul>
  </div>
</div>