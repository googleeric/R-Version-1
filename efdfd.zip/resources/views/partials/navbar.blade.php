<!-- Header Area-->
<div class="header-area" id="headerArea">
  <div class="container h-100 d-flex align-items-center justify-content-between">
    <!-- Logo Wrapper-->
    <div class="logo-wrapper"><a href="home.html"><img src="../assets/../assets/img/core-img/logo-small.png" alt=""></a></div>
    <!-- Search Form-->
    <div class="top-search-form">
      <form action="#" method="POST">
        <input class="form-control" type="search" placeholder="Enter your keyword">
        <button type="submit"><i class="fa fa-search"></i></button>
      </form>
    </div>
    <!-- Navbar Toggler-->
    <div class="suha-navbar-toggler d-flex justify-content-between flex-wrap" id="suhaNavbarToggler"><span></span><span></span><span></span></div>
  </div>
</div>